CAMBIOS DE ESTA VERSION

- Los botones/logos/enlaces de Telegram de la app abren https://t.me/SENSIOGCUBA.
- El nombre visible “Panther iOS” se cambió a “SENSI OG” en la cabecera de marca y en el título del aviso de la pantalla Patches.

NOTA SOBRE EL ERROR DE FREE FIRE MAX
El aviso “The app bundle com.dts.freefiremax is not installed or cannot be opened” indica que iOS/el sistema de parches no encuentra Free Fire MAX instalado con ese identificador. Cambiar el nombre o el enlace de Telegram no corrige ese problema. Instala la versión compatible de Free Fire MAX y vuelve a intentar. Si ya está instalada, puede tratarse de una versión cuyo identificador de paquete no coincide; no se ha modificado a ciegas el identificador de la app/juego.

Estos cambios de código no han sido compilados ni probados en un dispositivo iOS.
